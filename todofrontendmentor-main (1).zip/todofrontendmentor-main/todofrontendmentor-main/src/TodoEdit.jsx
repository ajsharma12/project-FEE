// TodoEdit.js
import React, { useState, useEffect } from "react";

function TodoEdit({ editTodoId, todos, setTodos, setEditTodoId }) {
    const [editedText, setEditedText] = useState("");

    useEffect(() => {
        const todoToEdit = todos.find((todo) => todo.id === editTodoId);
        if (todoToEdit) {
            setEditedText(todoToEdit.text);
        }
    }, [editTodoId, todos]);

    const handleEditSave = () => {
        const filteredArray = todos.filter((todo) => todo.id === editTodoId);
        console.log()
        filteredArray[0].title=editedText
        setEditedText("");
        // setTodos({...todo, text: editedText});
        // setTodos((prevTodos) =>
        //     prevTodos.map((todo) =>
        //         todo.id === editTodoId
        //             ? { ...todo, text: editedText }
        //             : todo
        //     )
        // );
        setEditTodoId(null); // Close the edit form
    };

    return (
        <div className="min-h-screen flex justify-center items-center ">
            <div className="h-[300px] w-[500px] bg-gray-300 flex flex-col">
                <input
                    type="text"
                    value={editedText}
                    onChange={(e) => setEditedText(e.target.value)}
                    />
                <button onClick={handleEditSave}>Save</button>
                </div>
        </div>
    );
}

export default TodoEdit;
